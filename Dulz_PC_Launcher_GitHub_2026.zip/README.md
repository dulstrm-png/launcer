# Dulz PC Launcher 2026

Native Android desktop-style launcher by **Dulz | STRM**.

## Fitur

- Desktop PC futuristik ringan
- Portrait + landscape
- Taskbar dan Start Menu
- Jam/tanggal realtime
- BluStrak dengan Android DownloadManager
- Membuka Chrome asli jika tersedia
- File Explorer dengan Storage Access Framework
- Settings
- Search
- Android HOME / DEFAULT / LAUNCHER intent filter
- GitHub Actions untuk build APK

## GitHub Actions

Upload project ke GitHub pada branch `main`.

Kemudian buka:

**Actions → Build Dulz PC Launcher → Run workflow**

APK hasil build akan tersedia pada bagian **Artifacts**.

## Build lokal

Gunakan Android Studio modern dengan Android SDK 35 dan Java 17.

```bash
./gradlew assembleDebug
```

APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Catatan

BluStrak tidak memakai tombol download palsu. Download menggunakan Android `DownloadManager` dan membutuhkan URL HTTP/HTTPS yang valid.
