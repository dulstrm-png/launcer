package com.dulz.pc

import android.app.Activity
import android.app.DownloadManager
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var desktop: DesktopView
    private var overlay: View? = null
    private val prefs by lazy { getSharedPreferences("dulz_pc", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )
        desktop = DesktopView(this)
        setContentView(desktop)
    }

    override fun onBackPressed() {
        if (overlay != null) {
            closeOverlay()
        } else {
            super.onBackPressed()
        }
    }

    private fun showOverlay(view: View) {
        overlay = view
        (view as? ViewGroup)?.alpha = 0f
        setContentView(view)
        view.animate().alpha(1f).setDuration(180).start()
    }

    private fun closeOverlay() {
        overlay = null
        setContentView(desktop)
    }

    private fun rounded(bg: Int, radius: Float = 22f): GradientDrawable =
        GradientDrawable().apply {
            setColor(bg)
            cornerRadius = radius
            setStroke(1, Color.argb(55, 255, 255, 255))
        }

    private fun openStart() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 26, 28, 20)
            background = rounded(Color.argb(238, 8, 16, 30), 28f)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val profile = TextView(this).apply {
            text = "●  Dulz PC\n    Dulz | STRM"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(4, 0, 12, 8)
        }
        top.addView(profile, LinearLayout.LayoutParams(0, -2, 1f))
        val power = Button(this).apply {
            text = "⏻"
            setTextColor(Color.WHITE)
            background = rounded(Color.TRANSPARENT, 18f)
            setOnClickListener { closeOverlay(); Toast.makeText(this@MainActivity, "Power menu Android", Toast.LENGTH_SHORT).show() }
        }
        top.addView(power, LinearLayout.LayoutParams(60, 60))
        root.addView(top)

        val search = EditText(this).apply {
            hint = "Search apps..."
            hintTextColor = Color.LTGRAY
            setTextColor(Color.WHITE)
            singleLine = true
            background = rounded(Color.argb(55, 255, 255, 255), 18f)
            setPadding(22, 0, 22, 0)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, 58).apply { bottomMargin = 18 })

        val apps = listOf(
            "🎮  BluStrak" to { openBluStrak() },
            "🌐  Chrome" to { openChrome() },
            "📁  File Explorer" to { openExplorer() },
            "⚙️  Settings" to { openSettings() },
            "🔍  Search" to { openSearch() },
            "🛒  Game Store" to { openBluStrak() }
        )
        apps.forEach { (name, action) ->
            val b = Button(this).apply {
                text = name
                textSize = 16f
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setTextColor(Color.WHITE)
                background = rounded(Color.argb(28, 255, 255, 255), 16f)
                setOnClickListener { action() }
            }
            root.addView(b, LinearLayout.LayoutParams(-1, 54).apply { bottomMargin = 8 })
        }
        val frame = FrameLayout(this)
        frame.setPadding(0, 0, 0, 16)
        frame.addView(root, FrameLayout.LayoutParams(-1, -1))
        showOverlay(frame)
    }

    private fun openChrome() {
        val pm = packageManager
        val intent = pm.getLaunchIntentForPackage("com.android.chrome")
        if (intent != null) startActivity(intent)
        else Toast.makeText(this, "Google Chrome belum terpasang.", Toast.LENGTH_SHORT).show()
    }

    private fun openExplorer() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, 1001)
    }

    private fun openSearch() {
        val e = EditText(this).apply {
            hint = "Search Android..."
            setTextColor(Color.WHITE)
            hintTextColor = Color.LTGRAY
            singleLine = true
            background = rounded(Color.argb(60, 255,255,255), 18f)
            setPadding(20,0,20,0)
        }
        val b = Button(this).apply {
            text = "Search"
            setOnClickListener {
                val q = e.text.toString().trim()
                if (q.isNotEmpty()) {
                    startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", q))
                }
            }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            background = rounded(Color.rgb(8,16,30), 28f)
            addView(TextView(this@MainActivity).apply {
                text = "Dulz Search"
                textSize = 26f
                setTextColor(Color.WHITE)
                setPadding(0,0,0,20)
            })
            addView(e, LinearLayout.LayoutParams(-1,60))
            addView(b, LinearLayout.LayoutParams(-1,60))
        }
        showOverlay(FrameLayout(this).apply {
            setPadding(25,25,25,25)
            addView(box, FrameLayout.LayoutParams(-1,-2,Gravity.CENTER))
        })
    }

    private fun openSettings() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(26, 26, 26, 26)
            background = rounded(Color.rgb(7,15,28), 26f)
        }
        root.addView(TextView(this).apply {
            text = "Settings"
            textSize = 28f
            setTextColor(Color.WHITE)
            setPadding(0,0,0,18)
        })
        val options = listOf(
            "Wallpaper" to { Toast.makeText(this, "Wallpaper: gunakan wallpaper internal launcher pada versi awal.", Toast.LENGTH_SHORT).show() },
            "Theme Dark / Light" to { toggleTheme() },
            "Taskbar" to { Toast.makeText(this, "Taskbar selalu aktif.", Toast.LENGTH_SHORT).show() },
            "Desktop icons" to { Toast.makeText(this, "Ikon desktop aktif.", Toast.LENGTH_SHORT).show() },
            "Animation" to { Toast.makeText(this, "Animasi halus aktif.", Toast.LENGTH_SHORT).show() },
            "Sound" to { Toast.makeText(this, "Sound mengikuti volume media Android.", Toast.LENGTH_SHORT).show() },
            "About Dulz PC Launcher" to { Toast.makeText(this, "Dulz PC Launcher 2026 • Dulz | STRM", Toast.LENGTH_LONG).show() }
        )
        options.forEach { (label, action) ->
            root.addView(Button(this).apply {
                text = label
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setTextColor(Color.WHITE)
                background = rounded(Color.argb(32,255,255,255),16f)
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(-1,56).apply { bottomMargin=8 })
        }
        root.addView(Button(this).apply {
            text = "← Back"
            setOnClickListener { closeOverlay() }
        })
        showOverlay(FrameLayout(this).apply {
            setPadding(22,22,22,22)
            addView(root, FrameLayout.LayoutParams(-1,-1))
        })
    }

    private fun toggleTheme() {
        prefs.edit().putBoolean("light", !prefs.getBoolean("light", false)).apply()
        Toast.makeText(this, "Theme berubah. Buka ulang launcher untuk menerapkan seluruh tampilan.", Toast.LENGTH_SHORT).show()
    }

    private fun openBluStrak() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22,22,22,22)
            background = rounded(Color.rgb(6,13,25), 24f)
        }
        root.addView(TextView(this).apply {
            text = "🎮  BluStrak"
            textSize = 28f
            setTextColor(Color.WHITE)
            setPadding(0,0,0,8)
        })
        root.addView(TextView(this).apply {
            text = "Game & app store • Download manager Android"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0,0,0,18)
        })

        val url = EditText(this).apply {
            hint = "Paste URL APK / file yang valid"
            setTextColor(Color.WHITE)
            hintTextColor = Color.LTGRAY
            singleLine = true
            background = rounded(Color.argb(45,255,255,255),16f)
            setPadding(18,0,18,0)
        }
        root.addView(url, LinearLayout.LayoutParams(-1,58).apply { bottomMargin=10 })

        val download = Button(this).apply {
            text = "Download"
            setOnClickListener {
                val u = url.text.toString().trim()
                if (!u.startsWith("http://") && !u.startsWith("https://")) {
                    Toast.makeText(this@MainActivity, "Masukkan URL http/https yang valid.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                try {
                    val request = DownloadManager.Request(Uri.parse(u))
                        .setTitle("BluStrak Download")
                        .setDescription(u)
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "BluStrak_${System.currentTimeMillis()}")
                    val id = (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                    Toast.makeText(this@MainActivity, "Download dimulai • ID $id", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "URL tidak dapat diproses: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
        root.addView(download, LinearLayout.LayoutParams(-1,58).apply { bottomMargin=18 })

        root.addView(TextView(this).apply {
            text = "Game list\n\n• Contoh Game A — 250 MB — v1.0\n• Contoh Game B — 1.2 GB — v2.4\n\nTambahkan URL file nyata untuk mengunduh. BluStrak tidak mengklaim menyediakan APK jika URL belum diberikan."
            textSize = 15f
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(-1,0,1f))

        root.addView(Button(this).apply {
            text = "← Back"
            setOnClickListener { closeOverlay() }
        })
        showOverlay(FrameLayout(this).apply {
            setPadding(20,20,20,20)
            addView(root, FrameLayout.LayoutParams(-1,-1))
        })
    }

    private inner class DesktopView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val apps = listOf(
            Triple("🎮","BluStrak") { openBluStrak() },
            Triple("🌐","Chrome") { openChrome() },
            Triple("📁","File Explorer") { openExplorer() },
            Triple("⚙️","Settings") { openSettings() },
            Triple("🔍","Search") { openSearch() },
            Triple("🛒","Game Store") { openBluStrak() }
        )
        private var phase = 0f
        private var downX = 0f
        private var downY = 0f

        init {
            isFocusable = true
            setBackgroundColor(Color.rgb(4,9,19))
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            phase += 0.006f
            val w = width.toFloat()
            val h = height.toFloat()
            val bg = LinearGradient(0f,0f,w,h, intArrayOf(Color.rgb(3,9,20),Color.rgb(7,21,42),Color.rgb(2,7,15)), null, Shader.TileMode.CLAMP)
            paint.shader = bg
            c.drawRect(0f,0f,w,h,paint)
            paint.shader = null

            // lightweight animated glow
            paint.color = Color.argb(28, 0, 190, 255)
            val gx = w * (0.25f + 0.12f * kotlin.math.sin(phase))
            val gy = h * 0.32f
            c.drawCircle(gx, gy, w*0.25f, paint)
            paint.color = Color.argb(20, 60, 100, 255)
            c.drawCircle(w*0.8f, h*0.55f, w*0.28f, paint)

            val cols = if (w < 600) 3 else 4
            val cellW = w / cols
            val startY = 50f
            apps.forEachIndexed { i, app ->
                val col = i % cols
                val row = i / cols
                val x = cellW * col + cellW/2
                val y = startY + row*120f
                paint.color = Color.argb(80,255,255,255)
                c.drawRoundRect(x-34,y-34,x+34,y+34,18f,18f,paint)
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = 34f
                paint.color = Color.WHITE
                c.drawText(app.first,x,y+12,paint)
                paint.textSize = 14f
                paint.color = Color.WHITE
                c.drawText(app.second,x,y+58,paint)
            }

            // taskbar
            val barH = if (h > w) 72f else 64f
            paint.color = Color.argb(215,5,10,20)
            c.drawRect(0,h-barH,w,h,paint)
            paint.color = Color.argb(45,255,255,255)
            c.drawRect(0,h-barH,w,h-barH+1,paint)

            paint.color = Color.WHITE
            paint.textAlign = Paint.Align.LEFT
            paint.textSize = 18f
            c.drawText("Dulz",18f,h-barH/2+7,paint)
            paint.textSize = 13f
            val date = SimpleDateFormat("EEE, dd MMM • HH:mm", Locale.getDefault()).format(Date())
            paint.textAlign = Paint.Align.RIGHT
            c.drawText(date,w-18f,h-barH/2+5,paint)

            postInvalidateDelayed(40)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.action == MotionEvent.ACTION_DOWN) {
                downX=e.x; downY=e.y; return true
            }
            if (e.action == MotionEvent.ACTION_UP) {
                val dx=e.x-downX; val dy=e.y-downY
                if (kotlin.math.abs(dx)<35 && kotlin.math.abs(dy)<35) {
                    val h=height.toFloat(); val barH=if(h>width)72f else 64f
                    if (e.y >= h-barH && e.x < 120) {
                        openStart(); return true
                    }
                    val cols=if(width<600)3 else 4
                    val cellW=width.toFloat()/cols
                    val startY=50f
                    apps.forEachIndexed { i, app ->
                        val col=i%cols; val row=i/cols
                        val x=cellW*col+cellW/2; val y=startY+row*120f
                        if (kotlin.math.abs(e.x-x)<50 && kotlin.math.abs(e.y-y)<75) {
                            app.third(); return@forEachIndexed
                        }
                    }
                }
                return true
            }
            return true
        }
    }
}
